package com.example.vangelis.my_health;

import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.res.XmlResourceParser;
import android.net.Uri;
import android.os.Environment;
import android.support.v4.content.FileProvider;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;

/**
 * Created by Vangelis on 13-Oct-17.
 */
import android.app.Activity;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.security.Provider;
import java.util.ArrayList;

import static com.example.vangelis.my_health.R.id.toggleButton;


public class Send extends android.support.v4.app.Fragment implements View.OnClickListener {
    ListView myList;
    Button sendButton;
    Uri fileUri ;
    BluetoothAdapter adapter1 = null;
    protected Activity activity;
    ToggleButton toggleButton ;

    View rootView;
    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        this.activity = (Activity) activity;
    }
    public View onCreateView(LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {
        toggleButton=(ToggleButton) activity.findViewById(R.id.toggleButton);
        toggleButton.setVisibility(View.GONE);
        // Other Code
        final File sdCard = Environment.getExternalStorageDirectory();
        ArrayList<String> FilesInFolder = GetFiles(sdCard.getAbsolutePath() + "/dir1/dir2");
        rootView =inflater.inflate(R.layout.fragment_send, container, false);


        myList = (ListView)rootView.findViewById(R.id.list);
        sendButton = (Button)rootView.findViewById(R.id.sendButton);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_multiple_choice,FilesInFolder);
        myList.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        myList.setAdapter(adapter);

        sendButton.setOnClickListener(new Button.OnClickListener(){

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub

                String selected = "";
                int cntChoice = myList.getCount();
                ArrayList<Uri> txts =new ArrayList<Uri>();
                SparseBooleanArray sparseBooleanArray = myList.getCheckedItemPositions();

                for(int i = 0; i < cntChoice; i++){
                    selected = "";
                    if(sparseBooleanArray.get(i)) {
                        selected += myList.getItemAtPosition(i).toString() ;
                        txts.add(Uri.fromFile(new File(sdCard.getAbsolutePath() + "/dir1/dir2/"+selected)));
                    }
                }

                adapter1 = BluetoothAdapter.getDefaultAdapter();

                Intent shareIntent=new Intent();
                shareIntent.setAction(Intent.ACTION_SEND_MULTIPLE);
                shareIntent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, txts);
                shareIntent.setType("*/*");
                shareIntent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(shareIntent , "Share ..."));

                Toast.makeText(getActivity(),"Sendings your files",Toast.LENGTH_LONG).show();
            }});
        return rootView;
    }
    public ArrayList<String> GetFiles(String DirectoryPath) {
        ArrayList<String> MyFiles = new ArrayList<String>();
        File f = new File(DirectoryPath);

        f.mkdirs();
        File[] files = f.listFiles();
        if (files.length == 0)
            return null;
        else {
            for (int i=0; i<files.length; i++)
                MyFiles.add(files[i].getName());
        }

        return MyFiles;
    }
    @Override
    public void onClick(View v) {

    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        toggleButton=(ToggleButton) activity.findViewById(R.id.toggleButton);
        toggleButton.setVisibility(View.VISIBLE);

    }
}
