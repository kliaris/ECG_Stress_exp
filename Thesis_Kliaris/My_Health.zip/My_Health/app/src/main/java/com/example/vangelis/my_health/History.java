package com.example.vangelis.my_health;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import static com.example.vangelis.my_health.R.id.toggleButton;

/**
 * Created by Vangelis on 12-Oct-17.
 */

public class History extends android.support.v4.app.Fragment implements View.OnClickListener {

    protected Activity activity;
    ToggleButton toggleButton ;
    View rootView;
    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        this.activity = (Activity) activity;
    }
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Other Code
        toggleButton=(ToggleButton) activity.findViewById(R.id.toggleButton);
        toggleButton.setVisibility(View.GONE);
        rootView =inflater.inflate(R.layout.fragment_history, container, false);
        final ListView lv;
        final File sdCard = Environment.getExternalStorageDirectory();
        ArrayList<String> FilesInFolder = GetFiles(sdCard.getAbsolutePath() + "/dir1/dir2");
        lv = (ListView)rootView.findViewById(R.id.filelist);

        lv.setAdapter(new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1, FilesInFolder));


        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                // Clicking on items
                String selectedFromList = (String) lv.getItemAtPosition(position);
                System.out.println(sdCard.getAbsolutePath() + "/dir1/dir2/"+selectedFromList);


                //Read text from file
                StringBuilder text = new StringBuilder();
                try {
                    BufferedReader br = new BufferedReader(new FileReader(sdCard.getAbsolutePath() + "/dir1/dir2/"+selectedFromList));
                    String line;

                    while ((line = br.readLine()) != null) {
                        text.append(line);
                        text.append('\n');
                    }
                    br.close();
                }
                catch (IOException e) {
                    //You'll need to add proper error handling here
                }

                //Find the view by its id
                TextView tv = (TextView)rootView.findViewById(R.id.display_text);
                tv.setMovementMethod(new ScrollingMovementMethod());    // gia na kanei scroll(exw valei kai stiw idiotites tou textView)
                //Set the text
                tv.setText(text.toString());
            }
        });

        return rootView;
    }

    public ArrayList<String> GetFiles(String DirectoryPath) {
        ArrayList<String> MyFiles = new ArrayList
                <String>();
        File f = new File(DirectoryPath);

        f.mkdirs();
        File[] files = f.listFiles();
        if (files.length == 0)
            return null;
        else {
            for (int i=0; i<files.length; i++)
                MyFiles.add(files[i].getName());
        }

        return MyFiles;
    }
    @Override
    public void onClick(View v) {

    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        toggleButton=(ToggleButton) activity.findViewById(R.id.toggleButton);
        toggleButton.setVisibility(View.VISIBLE);

    }
}
